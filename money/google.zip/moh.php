<?php
$urls = array(
"http://www.google.com/search?q=Google+Pension+Pixel+2",
"http://www.google.com/search?q=Android+Q+Beta+1+Arrives",
"http://www.google.com/search?q=ASUS+Releases+ZenBook+Flip+13",
"http://www.google.com/search?q=How+to+Install+Navigation+Gesture+iPhone+X",
"http://www.google.com/search?q=How+to+Uninstall+a+Default+App+on+Android",
"http://www.google.com/search?q=AnTuTu+Snapdragon+675+Score",
"http://www.google.com/search?q=How+To+Protect+Against+Ransomware+Virus",
);
$url = $urls[array_rand($urls)];
header("Location: $url");
?>